const express = require('express');
const app = express();
const path = require('path');
const passport = require('passport');
const db = require("./config/database");
const homeRouter = require("./routes/home_router");
const addPostRouter = require("./routes/addPost_router");
const dbRouter = require("./routes/db_router");
const adminRouter = require("./routes/admin_router");
const accountRouter = require("./routes/account_router");
require('./config/passport')(passport);


app.use(express.static(path.join(__dirname + '/public')));
app.set('views', path.join(__dirname + '/public/view'));
app.engine('html', require('ejs').renderFile);
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));
app.use(require('express-session')({
    secret: 'keyboard cat',
    resave: true,
    saveUninitialized: true
}))
app.use(passport.initialize());
app.use(passport.session());
app.use("/", homeRouter);
app.use("/db", dbRouter);
app.use("/admin", adminRouter);
app.use("/account", accountRouter);
app.use("/addpost", addPostRouter);


const port = process.env.PORT || 3000;
app.listen(port);