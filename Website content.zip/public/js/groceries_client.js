$('document').ready(function () {
    // Change title
    document.getElementById("title").innerHTML = "Groceries";

    var groceries = []
    
    // If database connection is good then query all items and populate grocery list.
    $.get("/db/testcon", function () {
    }).done(function (data) {
        populateGroceryList();
    });


    document.getElementById("addButton").onclick = function() {
        newElement();
    }
    
    // Called when the "Add" button is pressed
    // Also called when page is called, when querying all groceries from database. 
    // Creates a new list item and adds it to the database
    function newElement(itemFromDB) {
    
        var inputValue = itemFromDB || document.getElementById("myInput").value;
        
        // Checking for doubles
        if (groceries.includes(inputValue)) {
            alert("No duplicate groceries!");
            document.getElementById("myInput").value = "";
            return;
        }
    
        groceries.push(inputValue);
        
        var li = document.createElement("li");
        var t = document.createTextNode(inputValue);
        li.appendChild(t);
        if (inputValue === '') {
            alert("You must write something!");
            return;
        } else {
            document.getElementById("myUL").appendChild(li);
        }
        document.getElementById("myInput").value = "";
        
        var span = document.createElement("SPAN");
        var txt = document.createTextNode("\u00D7"); // "\u00D7" = The multiplication character "x". 
        span.className = "close_" + inputValue;
        span.appendChild(txt);
        li.appendChild(span);
    
        var close = document.getElementsByClassName("close_" + inputValue)[0];
        close.onclick = function () {
            var div = this.parentElement;
            div.style.display = "none";
            deleteFromDB(close.className.substr(6));
        }
    
        if (itemFromDB == null)
            addToDB(inputValue);
    }
    
    // Queries all groceries to populate grocery list.
    function populateGroceryList() {
        $.post("/db/select", {query:'*', table:'Groceries'}, function() {
        }).done(function (data) {
            for (var i = 0; i < data.length; i++) {
                newElement(data[i]["GroceryName"]);
            }
        }).fail(function (err) {
            alert("Something went wrong when populating the grocery list");
        })
    }
    
    // Deletes a grocery from the database
    function deleteFromDB(grocery) {
        $.post("/db/delete", {table:'Groceries', columns:"GroceryName", values:"'"+grocery+"'"}, function() {
        }).fail(function (err) {
            alert("Something went wrong when deleting from the database");
        })
    }
    
    // Adds a grocery to the database.
    function addToDB(grocery) {
        $.post("/db/add", {table:'Groceries', columns:"GroceryName", values:"'"+grocery+"'"}, function() {
        }).fail(function (err) {
            alert("Something went wrong when inserting into database");
        })
    }
});
