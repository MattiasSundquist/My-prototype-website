$('document').ready(function () {
    
    displayAllPosts();

});

function displayAllPosts() {
    $.post("/db/select", {query:'*', table:'Posts'}, function() {
    }).done(function (data) {
        for (var i = data.length - 1; i >= 0; i--) {
            var postDiv = document.getElementById("postDiv");
            var article = document.createElement("article");
            article.className = "media content-section"
            postDiv.appendChild(article);
            
            var articleDiv = document.createElement("div")
            articleDiv.className = "media-body"
            article.appendChild(articleDiv)

            var metaDataDiv = document.createElement("div")
            metaDataDiv.className = "article-metadata"
            articleDiv.appendChild(metaDataDiv);

            var author = document.createElement("a")
            author.className = "mr-2"
            author.href = "/"
            author.innerText = data[i].PostAuthor
            metaDataDiv.appendChild(author);

            var date = document.createElement("small")
            date.className = "text-muted"
            date.innerText = data[i].PostDate
            metaDataDiv.appendChild(date);

            var h2 = document.createElement("h2")
            var title = document.createElement("a")
            title.className = "article-title"
            title.innerText = data[i].PostTitle
            h2.appendChild(title);
            articleDiv.appendChild(h2)

            var content = document.createElement("p")
            content.className = "article-content"
            content.innerText = data[i].PostContent
            articleDiv.appendChild(content)
        }
    }).fail(function(err) {
        alert("Something went wrong: " + err)
    })
}