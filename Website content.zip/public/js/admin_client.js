document.getElementById("title").innerHTML = "Admin login";

function login() {
    var inputPass = document.getElementById("password").value;
    window.location.href = "/admin/" + inputPass;
}