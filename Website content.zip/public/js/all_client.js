$('document').ready(function () {

    // If user is logged in:
    //      Show username instead of Login/Register
    //      Show navitem "Create post"
    $.get("/account/getusername", function () {}).done(function (data) {
        if (data == 'No user') {
            
        } else {
            document.getElementById("navItemCreatePost").hidden = false;
            var navItem = document.getElementById("navItemAccount");
            navItem.innerHTML = data
        }
    })
});