
// Called when user clicks signup button
document.getElementById("btn-signup").onclick = function () {

    // Get all input references
    var email = document.getElementById("signup_email").value;
    var username = document.getElementById("signup_username").value;
    var pass = document.getElementById("signup_password").value;
    var confPass = document.getElementById("signup_confirm_password").value;

    // Input validation check
    if (!email.includes("@") || email.length < 10) {
        $('#signup_email_alert').show();
        return;
    } else
        $('#signup_email_alert').hide();

    if (username.length < 5) {
        $('#signup_username_alert').show();
        return;
    } else
        $('#signup_username_alert').hide();

    if (pass.length < 5) {
        $('#signup_password_alert').show();
        return;
    } else
        $('#signup_password_alert').hide();

    if (pass != confPass) {
        $('#signup_confirm_password_alert').show();
        return;
    } else
        $('#signup_confirm_password_alert').hide();
}