var express = require('express');
var router = express.Router();
const passport = require('passport');
const db = require("../config/database")


router.get("/signin", function (req, res) {
    if (req.user != null)
        res.send("Not implemented. Go back!")
    else
        res.render('sign_in.html');
});


router.post('/signin', function (req, res, next) {
    passport.authenticate('local', function (err, user, info) {
        if (err) {
            return next(err);
        }
        if (!user) {
            return res.send('No such user, go back and try again.');
        }
        req.logIn(user, function (err) {
            if (err) {
                return next(err);
            }
            console.log("Successful login for:", req.user);
            return res.redirect('/');
        });
    })(req, res, next);
});


router.get("/signup", function (req, res) {
    res.render('sign_up.html');
});


router.post("/signup", function (req, res, next) {
    if (validateSignUp(req.body)) {
        db.addTo('Accounts', "AccountEmail, AccountName, AccountPassword", "'" + req.body.email + "','" + req.body.username + "','" + req.body.password + "'", function (err, data) {
            if (err)
                console.log(err)

            passport.authenticate('local', function (err, user, info) {
                if (err) {
                    return next(err);
                }
                if (!user) {
                    return res.redirect('/account/signin');
                }
                req.logIn(user, function (err) {
                    if (err) {
                        return next(err);
                    }
                    console.log("Successful login for:", req.user);
                    return res.redirect('/');
                });
            })(req, res, next);
        })
    }
})


router.get("/getusername", function (req, res) {
    if (req.user != null)
        res.send(req.user.username);
    else res.send("No user");
})


function validateSignUp(body) {
    if (body != null) {
        if (body.email.includes("'") || body.username.includes("'") || body.password.includes("'"))
            return false
        return true
    }
    return false
}

module.exports = router;