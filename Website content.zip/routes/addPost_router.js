var express = require('express');
var router = express.Router();
var db = require("../config/database")

router.get("/", function (req, res) {
    if (req.user != null)
        res.render('addPost.html');
    else
        res.send('Error! You must be logged in to view this page.')
});


router.post("/", function (req, res) {
    if (req.user != null) {
        var isValid = validateInput(req.body);
        if (isValid) {
            var d = new Date().toString();
            d = d.split(" GMT");
            db.addTo('Posts', "PostAuthor, PostDate, PostTitle, PostContent", "'" + req.user.username + "', '" + d[0] + "', '" + req.body.title + "', '" + req.body.content + "'", function (err, data) {
                if (err)
                    res.send("Something went wrong: " + err)
                else
                    res.redirect("/");
            })
        } else {
            res.send("No ' characters allowed")
        }
    } else
        res.send('Error! You must be logged in to create posts.')
})


function validateInput(body) {
    if (body.title.includes("'"))
        return false
    if (body.content.includes("'"))
        return false
    return true
}


module.exports = router;