var express = require('express');
var router = express.Router();

router.get("/", function (req, res) {
    if (req.user != null)
        if (req.user.username == 'Mattias')
            res.render('groceries.html');
        else
        res.render('admin.html');
    else
        res.render('admin.html');
});


router.get("/:password", function (req, res) {
    if (req.params.password == "a")
        res.render('groceries.html');
    else
        res.send("Wrong password!");
});

module.exports = router;