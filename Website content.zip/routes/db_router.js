var express = require('express');
var router = express.Router();
const db = require('../config/database');

router.get("/testcon", function (req, res) {
    res.send(db.testCon);
});


router.post("/select", function (req, res) {
    db.selectFrom(req.body.query, req.body.table, function (err, data) {
        if (!err) {
            res.send(data);
            //console.log(data);
        } else {
            res.send(err.stack);
            //console.log(err.stack);
        }
    });
})


router.post("/add", function (req, res) {
    db.addTo(req.body.table, req.body.columns, req.body.values, function (err, data) {
        if (!err) {
            //console.log(data);
        } else {
            //console.log(err.stack);
        }
    })
})


router.post("/delete", function (req, res) {
    db.deleteFrom(req.body.table, req.body.columns, req.body.values, function (err, data) {
        if (!err) {
            //console.log(data);
        } else {
            //console.log(err.stack);
        }
    })
})

module.exports = router;