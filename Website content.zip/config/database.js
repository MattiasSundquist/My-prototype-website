const mysql = require('mysql');

var connection = mysql.createConnection({
    host: process.env.host || 'mattiassundquist.cpv9kxt22qmt.eu-central-1.rds.amazonaws.com',
    user: process.env.user || 'mattiassundquist',
    password: process.env.password || 'Frimurarn88',
    database: 'mattiassundquist'
});


exports.testCon = connection.connect(function (err, data) {
    console.log("Testing database connection...");
    if (!err)
        console.log("Database connection OK");
    else
        console.log("Database connection FAILED");
});


exports.deleteFrom = function(table, column, query, callback) {
    //console.log("DELETE FROM " + table + " WHERE " + column + " = (" + query + ");");
    return connection.query("DELETE FROM " + table + " WHERE " + column + " = (" + query + ");", function (err, result) {
        if (err) callback(err, null);
        else {
            //console.log(result);
            callback(null, result);
        }
    });
} 


exports.addTo = function (table, columnNames, values, callback) {
    //console.log("INSERT INTO " + table + " (" + columnNames + ") VALUES (" + values + ");");
    return connection.query("INSERT INTO " + table + " (" + columnNames + ") VALUES (" + values + ");", function (err, result) {
        if (err) callback(err, null);
        else {
            //console.log(result);
            callback(null, result);
        }
    });
}


exports.selectFrom = function (select, table, callback) {
    //console.log("SELECT " + select + " FROM " + table);
    return connection.query("SELECT " + select + " FROM " + table, function (err, result) {
        if (err) callback(err, null);
        else {
            //console.log(result);
            callback(null, result);
        }
    });
}


exports.selectFromWhere = function (select, table, where, callback) {
    //console.log("SELECT " + select + " FROM " + table + " WHERE " + where);
    return connection.query("SELECT " + select + " FROM " + table + " WHERE " + where, function (err, result) {
        if (err) 
            throw err;
        else {
            //console.log(result);
            callback(null, result);
        }
    });
}