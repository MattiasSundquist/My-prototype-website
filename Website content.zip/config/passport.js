const LocalStrategy = require('passport-local').Strategy;
const db = require("./database");
//const bcrypt = require('bcryptjs');

module.exports = function (passport) {
    // Local Strategy
    passport.use(new LocalStrategy(function (username, password, done) {
        // Match Username
        db.selectFromWhere('*', 'Accounts', "AccountName='" + username + "';", function (err, data) {
            if (data.length > 0) {
                if (password == data[0].AccountPassword) {
                    user = {
                        id: data[0].AccountID,
                        username: data[0].AccountName,
                        password: data[0].AccountPassword
                    }
                    return done(null, user);
                } else {
                    console.log("password != data[0].AccountPassword \t in passport.js");
                    return done(null, err);
                }
            } else {
                return done(null, err);
            }

            // Match Password
            /*
            bcrypt.compare(password, user.password, function(err, isMatch){
              if(err) throw err;
              if(isMatch){
                return done(null, user);
              } else {
                return done(null, false, {message: 'Wrong password'});
              }
            });
            */
        });
    }));

    passport.serializeUser(function (user, done) {
        done(null, user.id);
    });

    passport.deserializeUser(function (id, done) {
        db.selectFromWhere('*', 'Accounts', "AccountID='" + id + "';", function (err, data) {
            if (data.length > 0) {
                user = {
                    id: data[0].AccountID,
                    username: data[0].AccountName,
                    password: data[0].AccountPassword
                }
                return done(null, user);
            } else {
                console.log("IS NULL!!!!!!!!");
            }
            done(err, user);
        });
    });
}
